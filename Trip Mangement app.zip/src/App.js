import TripManagement from './TripManagement';

export default function App() {
  return <TripManagement />;
}
