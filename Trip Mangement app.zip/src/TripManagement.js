import { useState, useEffect } from "react";

export default function TripManagement() {
  const LS_PLACES = "trip_demo_places_v1";
  const LS_BOOKINGS = "trip_demo_bookings_v1";

  const [places, setPlaces] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const [pName, setPName] = useState("");
  const [pCategory, setPCategory] = useState("tourist");
  const [pDesc, setPDesc] = useState("");

  const [bName, setBName] = useState("");
  const [bPlace, setBPlace] = useState("");
  const [bFrom, setBFrom] = useState("");
  const [bTo, setBTo] = useState("");
  const [bNotes, setBNotes] = useState("");

  // Helpers
  const uid = (prefix = "id") => prefix + "_" + Math.random().toString(36).slice(2, 9);

  const load = (key, fallback) => {
    try {
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    } catch {
      return fallback;
    }
  };
  const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));

  // Effects
  useEffect(() => {
    setPlaces(load(LS_PLACES, []));
    setBookings(load(LS_BOOKINGS, []));
  }, []);

  useEffect(() => save(LS_PLACES, places), [places]);
  useEffect(() => save(LS_BOOKINGS, bookings), [bookings]);

  // Handlers
  const addPlace = (e) => {
    e.preventDefault();
    if (!pName.trim()) return alert("Please provide a name");
    const place = {
      id: uid("place"),
      name: pName.trim(),
      category: pCategory,
      description: pDesc.trim(),
      createdAt: Date.now(),
    };
    setPlaces([place, ...places]);
    setPName("");
    setPDesc("");
    setPCategory("tourist");
  };

  const deletePlace = (id) => {
    if (!window.confirm("Delete this place?")) return;
    setPlaces(places.filter((p) => p.id !== id));
    setBookings(bookings.filter((b) => b.placeId !== id));
  };

  const toggleTourist = (id) => {
    setPlaces(
      places.map((p) =>
        p.id === id ? { ...p, category: p.category === "tourist" ? "city" : "tourist" } : p
      )
    );
  };

  const editPlace = (id) => {
    const p = places.find((x) => x.id === id);
    if (!p) return;
    setPName(p.name);
    setPCategory(p.category);
    setPDesc(p.description || "");
    setPlaces(places.filter((x) => x.id !== id));
  };

  const addBooking = (e) => {
    e.preventDefault();
    if (!bPlace) return alert("Select a place");
    const place = places.find((p) => p.id === bPlace);
    if (!place) return;
    const booking = {
      id: uid("booking"),
      user: bName.trim() || "Anonymous",
      placeId: place.id,
      placeName: place.name,
      from: bFrom || null,
      to: bTo || null,
      notes: bNotes.trim(),
      createdAt: Date.now(),
    };
    setBookings([booking, ...bookings]);
    setBName("");
    setBPlace("");
    setBFrom("");
    setBTo("");
    setBNotes("");
  };

  const cancelBooking = (id) => {
    if (!window.confirm("Cancel this booking?")) return;
    setBookings(bookings.filter((b) => b.id !== id));
  };

  const seedData = () => {
    const samplePlaces = [
      {
        id: uid("place"),
        name: "Jaipur Fort",
        category: "tourist",
        description: "Historic fort with palaces and courtyards",
        createdAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
      },
      {
        id: uid("place"),
        name: "Goa Beach",
        category: "nature",
        description: "Beaches, parties and coastal food",
        createdAt: Date.now() - 1000 * 60 * 60 * 24 * 8,
      },
      {
        id: uid("place"),
        name: "Mumbai City",
        category: "city",
        description: "Bustling metropolis and gateway",
        createdAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
      },
    ];
    const sampleBookings = [
      {
        id: uid("booking"),
        user: "Asha Patel",
        placeId: samplePlaces[0].id,
        placeName: samplePlaces[0].name,
        from: null,
        to: null,
        notes: "Prefer guided tour",
        createdAt: Date.now() - 1000 * 60 * 60,
      },
    ];
    setPlaces(samplePlaces);
    setBookings(sampleBookings);
  };

  const clearData = () => {
    if (!window.confirm("Clear all stored places and bookings?")) return;
    setPlaces([]);
    setBookings([]);
  };

  // Filtered list
  const filteredPlaces = places.filter((p) => {
    if (filter !== "all" && p.category !== filter) return false;
    if (!search) return true;
    return (p.name + " " + (p.description || "")).toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <header className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-semibold">Trip Management — React Demo</h1>
          <p className="text-sm text-gray-600">
            Add places, mark tourist spots, and make bookings (stored locally).
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={seedData} className="px-3 py-1 rounded-lg bg-blue-100 text-blue-600">
            Seed sample data
          </button>
          <button onClick={clearData} className="px-3 py-1 rounded-lg bg-gray-200">
            Clear all data
          </button>
        </div>
      </header>

      <div className="grid md:grid-cols-[1fr_380px] gap-4 mt-4">
        {/* Places */}
        <section className="bg-white rounded-xl shadow p-4">
          <div className="flex justify-between items-center">
            <h2 className="font-medium">Places</h2>
            <div className="text-sm text-gray-500">Total: {filteredPlaces.length}</div>
          </div>

          <div className="flex gap-2 mt-3">
            <input
              type="text"
              placeholder="Search places..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 px-2 py-1 rounded border"
            />
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-2 py-1 rounded border"
            >
              <option value="all">All</option>
              <option value="tourist">Tourist</option>
              <option value="city">Cities</option>
              <option value="nature">Nature</option>
            </select>
          </div>

          <div className="mt-3 space-y-2">
            {filteredPlaces.length === 0 && <div className="text-sm text-gray-500">No places found</div>}
            {filteredPlaces.map((p) => (
              <div key={p.id} className="flex gap-3 items-center border rounded-lg p-2">
                <div className="w-12 h-12 flex items-center justify-center bg-blue-50 text-blue-600 font-bold rounded">
                  {p.name
                    .split(" ")
                    .map((s) => s[0])
                    .slice(0, 2)
                    .join("")}
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">{p.name}</h3>
                  <p className="text-sm text-gray-600">{p.description}</p>
                  <div className="flex gap-2 mt-1 text-xs">
                    <span className="bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">{p.category}</span>
                  </div>
                </div>
                <div className="flex flex-col gap-1 items-end">
                  <button onClick={() => toggleTourist(p.id)} className="px-2 py-1 text-xs bg-gray-100 rounded">
                    {p.category === "tourist" ? "Tourist" : "Mark tourist"}
                  </button>
                  <button onClick={() => editPlace(p.id)} className="px-2 py-1 text-xs bg-gray-100 rounded">
                    Edit
                  </button>
                  <button onClick={() => deletePlace(p.id)} className="px-2 py-1 text-xs bg-gray-100 rounded">
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Right column */}
        <aside className="space-y-4">
          <div className="bg-white rounded-xl shadow p-4">
            <h3 className="font-medium">Add a place</h3>
            <form onSubmit={addPlace} className="space-y-2 mt-2">
              <input
                value={pName}
                onChange={(e) => setPName(e.target.value)}
                placeholder="Name"
                className="w-full px-2 py-1 rounded border"
              />
              <select
                value={pCategory}
                onChange={(e) => setPCategory(e.target.value)}
                className="w-full px-2 py-1 rounded border"
              >
                <option value="tourist">Tourist</option>
                <option value="city">City</option>
                <option value="nature">Nature</option>
              </select>
              <textarea
                value={pDesc}
                onChange={(e) => setPDesc(e.target.value)}
                placeholder="Short description"
                className="w-full px-2 py-1 rounded border"
              />
              <div className="flex gap-2">
                <button type="submit" className="bg-blue-500 text-white rounded px-3 py-1">
                  Add place
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPName("");
                    setPDesc("");
                    setPCategory("tourist");
                  }}
                  className="bg-gray-100 rounded px-3 py-1"
                >
                  Reset
                </button>
              </div>
            </form>
          </div>

          <div className="bg-white rounded-xl shadow p-4">
            <h3 className="font-medium">Book a trip</h3>
            <form onSubmit={addBooking} className="space-y-2 mt-2">
              <input
                value={bName}
                onChange={(e) => setBName(e.target.value)}
                placeholder="Your name"
                className="w-full px-2 py-1 rounded border"
              />
              <select
                value={bPlace}
                onChange={(e) => setBPlace(e.target.value)}
                className="w-full px-2 py-1 rounded border"
              >
                <option value="">Select place</option>
                {places.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.category})
                  </option>
                ))}
              </select>
              <div className="flex gap-2">
                <input
                  type="date"
                  value={bFrom}
                  onChange={(e) => setBFrom(e.target.value)}
                  className="flex-1 px-2 py-1 rounded border"
                />
                <input
                  type="date"
                  value={bTo}
                  onChange={(e) => setBTo(e.target.value)}
                  className="flex-1 px-2 py-1 rounded border"
                />
              </div>
              <textarea
                value={bNotes}
                onChange={(e) => setBNotes(e.target.value)}
                placeholder="Notes"
                className="w-full px-2 py-1 rounded border"
              />
              <div className="flex gap-2">
                <button type="submit" disabled={!places.length} className="bg-blue-500 text-white rounded px-3 py-1">
                  Book
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setBName("");
                    setBPlace("");
                    setBFrom("");
                    setBTo("");
                    setBNotes("");
                  }}
                  className="bg-gray-100 rounded px-3 py-1"
                >
                  Reset
                </button>
              </div>
            </form>

            <div className="mt-3">
              <h4 className="font-medium text-sm mb-2">Your bookings</h4>
              {bookings.length === 0 && <div className="text-sm text-gray-500">No bookings yet</div>}
              {bookings.map((b) => (
                <div key={b.id} className="border rounded p-2 mb-2">
                  <div className="flex justify-between">
                    <div>
                      <strong>{b.user}</strong> — {b.placeName}
                    </div>
                    <div className="text-xs text-gray-500">
                      {new Date(b.createdAt).toLocaleString()}
                    </div>
                  </div>
                  <div className="text-xs text-gray-600">
                    {b.from ? `From: ${b.from}` : ""} {b.to ? `To: ${b.to}` : ""}
                  </div>
                  <div className="text-xs text-gray-600">Notes: {b.notes || "–"}</div>
                  <button
                    onClick={() => cancelBooking(b.id)}
                    className="mt-1 px-2 py-0.5 bg-gray-100 rounded text-xs"
                  >
                    Cancel
                  </button>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>

      <footer className="text-center text-sm text-gray-500 mt-4">
        Local demo — data saved to your browser's localStorage.
      </footer>
    </div>
  );
}
